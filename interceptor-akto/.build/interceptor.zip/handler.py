#!/usr/bin/env python3
"""
Akto guardrails interceptor for Amazon Bedrock AgentCore Gateway (MCP target).

Vendored from https://github.com/akto-api-security/aws-bedrock-agentcore
(lambda/interceptor/handler.py). Attached as a REQUEST + RESPONSE interceptor.

Akto contract:
  REQUEST  -> POST {AKTO_DATA_INGESTION_URL}/api/http-proxy?guardrails=true&...
  RESPONSE -> POST {AKTO_DATA_INGESTION_URL}/api/http-proxy?response_guardrails=true&...
  Auth     -> Authorization: <AKTO_API_TOKEN> (raw token, no "Bearer")
"""

import json
import logging
import os
import time
import urllib.request
from http import HTTPStatus
from typing import Any, Dict, Optional, Tuple

logger = logging.getLogger()
logger.setLevel(logging.INFO)

AKTO_DATA_INGESTION_URL = (os.getenv("AKTO_DATA_INGESTION_URL") or "").rstrip("/")
AKTO_API_TOKEN = os.getenv("AKTO_API_TOKEN", "")

AKTO_TIMEOUT = 5.0
AKTO_CONNECTOR = "agentcore_gateway"
CONTEXT_SOURCE = "AGENTIC"
INTERCEPTOR_OUTPUT_VERSION = "1.0"
GUARDED_METHODS = {"tools/call"}

_SENSITIVE_HEADERS = {"authorization", "cookie", "set-cookie", "x-api-key", "x-amz-security-token"}


def _build_http_proxy_url(*, guardrails: bool = False, response_guardrails: bool = False,
                          ingest_data: bool = False) -> str:
    params = []
    if guardrails:
        params.append("guardrails=true")
    if response_guardrails:
        params.append("response_guardrails=true")
    params.append(f"akto_connector={AKTO_CONNECTOR}")
    if ingest_data:
        params.append("ingest_data=true")
    return f"{AKTO_DATA_INGESTION_URL}/api/http-proxy?{'&'.join(params)}"


def _post_json(url: str, payload: Dict[str, Any]) -> Any:
    headers = {"Content-Type": "application/json"}
    if AKTO_API_TOKEN:
        headers["Authorization"] = AKTO_API_TOKEN
    req = urllib.request.Request(
        url, data=json.dumps(payload).encode("utf-8"), headers=headers, method="POST"
    )
    start = time.time()
    with urllib.request.urlopen(req, timeout=AKTO_TIMEOUT) as resp:
        raw = resp.read().decode("utf-8")
        logger.info("Akto response: status=%s duration=%dms size=%d",
                    resp.getcode(), int((time.time() - start) * 1000), len(raw))
        try:
            return json.loads(raw)
        except json.JSONDecodeError:
            return raw


def _parse_guardrails_result(result: Any) -> Tuple[bool, str, str, bool, str]:
    data = result.get("data", {}) if isinstance(result, dict) else {}
    gr = data.get("guardrailsResult", {}) if isinstance(data, dict) else {}
    if not isinstance(gr, dict):
        return True, "", "", False, ""
    allowed = gr.get("Allowed", True)
    reason = gr.get("Reason", "")
    behaviour = gr.get("behaviour", "") or gr.get("Behaviour", "")
    modified = gr.get("Modified", False)
    modified_payload = gr.get("ModifiedPayload", "")
    return allowed, reason, behaviour, modified, modified_payload


def _is_mcp_body(body: Any) -> bool:
    return isinstance(body, dict) and str(body.get("jsonrpc", "")) == "2.0"


def _build_tags(is_mcp: bool) -> Dict[str, str]:
    if is_mcp:
        return {"mcp-server": "MCP Server", "service": AKTO_CONNECTOR}
    return {"gen-ai": "Gen AI", "service": AKTO_CONNECTOR}


def _clean_headers(headers: Any) -> Dict[str, str]:
    if not isinstance(headers, dict):
        return {}
    return {k: v for k, v in headers.items()
            if isinstance(k, str) and k.lower() not in _SENSITIVE_HEADERS}


def _ensure_host(headers: Dict[str, str], is_mcp: bool) -> Dict[str, str]:
    if any(isinstance(k, str) and k.lower() == "host" for k in headers):
        return headers
    suffix = "mcp" if is_mcp else "ai-agent"
    return {**headers, "host": f"{AKTO_CONNECTOR}.{suffix}"}


def _client_ip(headers: Dict[str, str]) -> str:
    for key in ("X-Forwarded-For", "x-forwarded-for", "X-Real-Ip", "x-real-ip"):
        val = headers.get(key)
        if val:
            return val.split(",")[0].strip()
    return ""


def _status_phrase(code: int) -> str:
    try:
        return HTTPStatus(code).phrase
    except ValueError:
        return ""


def _build_ingest_payload(*, request_payload: str, response_payload: str,
                          request_headers: Dict[str, str], response_headers: Dict[str, str],
                          status_code: Optional[int], is_mcp: bool) -> Dict[str, Any]:
    tags = _build_tags(is_mcp)
    code = status_code if status_code is not None else 200
    request_headers = _ensure_host(request_headers, is_mcp)
    return {
        "path": "/mcp",
        "requestHeaders": json.dumps(request_headers),
        "responseHeaders": json.dumps(response_headers),
        "method": "POST",
        "requestPayload": request_payload,
        "responsePayload": response_payload,
        "ip": _client_ip(request_headers),
        "time": str(int(time.time() * 1000)),
        "statusCode": code,
        "type": "HTTP/1.1",
        "status": _status_phrase(code),
        "akto_account_id": "1000000",
        "akto_vxlan_id": 0,
        "is_pending": "false",
        "source": "MIRRORING",
        "tag": json.dumps(tags),
        "metadata": json.dumps(tags),
        "contextSource": CONTEXT_SOURCE,
    }


def _should_block(allowed: bool, behaviour: str) -> bool:
    if allowed:
        return False
    b = str(behaviour or "").strip().lower()
    if b in ("warn", "alert"):
        logger.info("Guardrail behaviour=%s — allowing (logged only, no block at gateway)", b)
        return False
    return True


def _block_message(reason: str, *, is_response: bool) -> str:
    subject = "Tool result" if is_response else "Tool request"
    return f"{subject} blocked by Akto policy: {reason}" if reason else \
        f"{subject} blocked by Akto policy"


def _maybe_parse(payload: Any) -> Optional[dict]:
    if isinstance(payload, dict):
        return payload
    if isinstance(payload, str) and payload.strip():
        try:
            parsed = json.loads(payload)
            return parsed if isinstance(parsed, dict) else None
        except json.JSONDecodeError:
            return None
    return None


def _jsonrpc_error(request_id: Any, message: str, status_code: int = 403) -> Dict[str, Any]:
    return {
        "interceptorOutputVersion": INTERCEPTOR_OUTPUT_VERSION,
        "mcp": {
            "transformedGatewayResponse": {
                "statusCode": status_code,
                "body": {
                    "jsonrpc": "2.0",
                    "id": request_id,
                    "error": {"code": -32000, "message": message},
                },
            }
        },
    }


def _passthrough_request(body: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "interceptorOutputVersion": INTERCEPTOR_OUTPUT_VERSION,
        "mcp": {"transformedGatewayRequest": {"body": body}},
    }


def _passthrough_response(body: Dict[str, Any], status_code: int) -> Dict[str, Any]:
    return {
        "interceptorOutputVersion": INTERCEPTOR_OUTPUT_VERSION,
        "mcp": {"transformedGatewayResponse": {"body": body, "statusCode": status_code}},
    }


def _handle_request(mcp: Dict[str, Any]) -> Dict[str, Any]:
    gateway_request = mcp.get("gatewayRequest", {}) or {}
    body = gateway_request.get("body", {}) or {}
    method = body.get("method", "")
    request_id = body.get("id")

    if method not in GUARDED_METHODS:
        logger.info("Pass-through (unguarded method): %s", method or "unknown")
        return _passthrough_request(body)

    if not AKTO_DATA_INGESTION_URL:
        logger.warning("AKTO_DATA_INGESTION_URL not set — fail-open pass-through")
        return _passthrough_request(body)

    tool_name = (body.get("params") or {}).get("name", "unknown")
    logger.info("Guardrailing REQUEST tools/call: %s", tool_name)

    try:
        payload = _build_ingest_payload(
            request_payload=json.dumps(body),
            response_payload=json.dumps({}),
            request_headers=_clean_headers(gateway_request.get("headers")),
            response_headers={},
            status_code=None,
            is_mcp=_is_mcp_body(body),
        )
        result = _post_json(_build_http_proxy_url(guardrails=True, ingest_data=True), payload)
        allowed, reason, behaviour, modified, modified_payload = _parse_guardrails_result(result)
    except Exception as e:
        logger.error("Akto guardrails error (REQUEST) — failing open: %s", e)
        return _passthrough_request(body)

    if _should_block(allowed, behaviour):
        logger.warning("BLOCKING tools/call %s: %s", tool_name, reason)
        return _jsonrpc_error(request_id, _block_message(reason, is_response=False))

    if modified and modified_payload:
        parsed = _maybe_parse(modified_payload)
        new_args = ((parsed or {}).get("params") or {}).get("arguments")
        if isinstance(new_args, dict):
            logger.info("Applying guardrail-modified arguments for %s", tool_name)
            new_body = dict(body)
            new_body["params"] = {**(body.get("params") or {}), "arguments": new_args}
            return _passthrough_request(new_body)
        logger.warning("Modified payload missing params.arguments — passing original through")

    return _passthrough_request(body)


def _handle_response(mcp: Dict[str, Any]) -> Dict[str, Any]:
    gateway_request = mcp.get("gatewayRequest", {}) or {}
    gateway_response = mcp.get("gatewayResponse", {}) or {}
    req_body = gateway_request.get("body", {}) or {}
    resp_body = gateway_response.get("body", {}) or {}
    status_code = gateway_response.get("statusCode", 200)
    request_id = resp_body.get("id", req_body.get("id"))
    is_streaming = bool(gateway_response.get("isStreamingResponse"))

    if req_body.get("method") not in GUARDED_METHODS:
        return _passthrough_response(resp_body, status_code)

    if "method" in resp_body:
        return _passthrough_response(resp_body, status_code)

    if not AKTO_DATA_INGESTION_URL:
        logger.warning("AKTO_DATA_INGESTION_URL not set — fail-open pass-through")
        return _passthrough_response(resp_body, status_code)

    tool_name = (req_body.get("params") or {}).get("name", "unknown")
    logger.info("Guardrailing RESPONSE tools/call result: %s (streaming=%s)",
                tool_name, is_streaming)

    try:
        payload = _build_ingest_payload(
            request_payload=json.dumps(req_body),
            response_payload=json.dumps(resp_body),
            request_headers=_clean_headers(gateway_request.get("headers")),
            response_headers=_clean_headers(gateway_response.get("headers")),
            status_code=status_code,
            is_mcp=_is_mcp_body(req_body),
        )
        result = _post_json(_build_http_proxy_url(response_guardrails=True), payload)
        allowed, reason, behaviour, modified, modified_payload = _parse_guardrails_result(result)
    except Exception as e:
        logger.error("Akto guardrails error (RESPONSE) — failing open: %s", e)
        return _passthrough_response(resp_body, status_code)

    if _should_block(allowed, behaviour):
        logger.warning("BLOCKING tools/call result %s: %s", tool_name, reason)
        return _jsonrpc_error(request_id, _block_message(reason, is_response=True),
                             status_code=200 if is_streaming else status_code)

    if modified and modified_payload:
        parsed = _maybe_parse(modified_payload)
        if parsed is not None:
            logger.info("Applying guardrail-modified result for %s", tool_name)
            new_body = parsed if "jsonrpc" in parsed else {
                "jsonrpc": "2.0", "id": request_id, "result": parsed.get("result", parsed)
            }
            return _passthrough_response(new_body, status_code)
        logger.warning("Modified response payload not JSON — passing original through")

    return _passthrough_response(resp_body, status_code)


def lambda_handler(event, context):
    try:
        mcp = event.get("mcp", {}) or {}
        if mcp.get("gatewayResponse") is not None:
            return _handle_response(mcp)
        return _handle_request(mcp)
    except Exception as e:
        logger.error("Interceptor fatal error — failing open: %s", e)
        mcp = event.get("mcp", {}) or {}
        if mcp.get("gatewayResponse") is not None:
            gr = mcp.get("gatewayResponse", {}) or {}
            return _passthrough_response(gr.get("body", {}) or {}, gr.get("statusCode", 200))
        return _passthrough_request((mcp.get("gatewayRequest", {}) or {}).get("body", {}) or {})
